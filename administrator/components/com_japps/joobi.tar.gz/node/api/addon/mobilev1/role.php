<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');
class Api_Mobilev1_Role_addon {
public function getRoleName($roleID){
return '';
}
public function getColumnName(){
return 'rolid';
}
public function getRoles(){
return array();
}
public function insertRole($uid,$equivalentRole){
}
public function deleteRole($uid,$equivalentRole){
}
}
<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');
WLoadFile('api.addon.framework.user' , JOOBI_DS_NODE );
class Api_Netcom_User_addon extends Api_Framework_User_addon{
}
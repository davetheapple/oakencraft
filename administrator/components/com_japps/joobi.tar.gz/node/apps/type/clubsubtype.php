<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');
 class Apps_Clubsubtype_type extends WTypes {
public $clubsubtype=array(
0=> 'None',
21=> 'Joobi Club Basic',
23=> 'Joobi Club Standard',
25=> 'Joobi Club Premium',
27=> 'Joobi Club Ultimate',
31=> 'Joobi App Basic',
33=> 'Joobi App Standard',
35=> 'Joobi App Premium',
37=> 'Joobi App Ultimate'
  );
 }

<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');
 class Apps_Cms_type extends WTypes {
public $cms=array(
16=> 'joomla16',
17=> 'joomla30',
30=> 'wp4',
40=> 'Drupal'
  );
 }

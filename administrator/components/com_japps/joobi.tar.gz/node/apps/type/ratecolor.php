<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */

 defined('JOOBI_SECURE') or die('J....');
class Apps_Ratecolor_type extends WTypes {
var $ratecolor=array(
'yellow'=>'Default',
'red'=> 'Red',
'orange'=>'Orange',
'blue'=> 'Blue'
);
}
<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');
class Apps_Report_type extends WTypes {
var $report=array(
0=>'No report',
1=>'Only if a task has been launched',
2=>'Always send a report'
  );
}
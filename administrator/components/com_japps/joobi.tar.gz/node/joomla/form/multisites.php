<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');
class WForm_Coremultisites extends WForms_default {
	function create() {
		if( file_exists(JPATH_ADMINISTRATOR. DS . 'components' . DS . 'com_multisites' . DS . 'helpers' . DS . 'utils.php') ) {
			@include_once( JPATH_ADMINISTRATOR. DS . 'components' . DS . 'com_multisites' . DS . 'helpers' . DS . 'utils.php');
			if ( class_exists( 'MultisitesHelperUtils') && method_exists( 'MultisitesHelperUtils', 'getComboSiteIDs') ) {
				$comboSiteIDs = MultisitesHelperUtils::getComboSiteIDs( $this->value, 'trucs[' . $this->element->sid . '][' . $this->element->map . ']', WText::t('1425439010GLOC') );
				if ( empty($comboSiteIDs) ) return false;
				$this->content = $comboSiteIDs;
				return true;
			}
		} else {
			return false;
		}
		return false;
	}
	function show() {
		return false;
	}
}

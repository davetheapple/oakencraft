<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');
class Netcom_Result_objectData {
public $status=false;public $result=null;public $code='';public $message='';public $version='1.0';
}
class Netcom_Result_object extends WClasses {
}
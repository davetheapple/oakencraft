<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */
defined('JOOBI_SECURE') or die('J....');
 class Output_Limit_type extends WTypes {
public $limit=array(
 '5'=>'5',
 '10'=>'10',
 '15'=>'15',
 '20'=>'20',
 '25'=>'25',
 '30'=>'30',
 '50'=>'50',
 '100'=>'100',
 '200'=>'200',
 '500'=>'500',
'1000'=>'1000',
'5000'=>'5000');
 }

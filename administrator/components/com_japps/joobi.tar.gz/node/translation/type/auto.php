<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */

defined('JOOBI_SECURE') or die('J....');
 class Translation_Auto_type extends WTypes {
var $auto=array(
-1=> 'Not translated', 
1=> 'Joobi translation', 
2=> 'Manual translation', 
100=> 'Automatic translation' 
  );
 }

<?php 
/** @copyright Copyright (c) 2007-2015 Joobi Limited. All rights reserved.
* @link joobi.co
* @license GNU GPLv3 */

defined('JOOBI_SECURE') or die('J....');
 class Translation_Engine_type extends WTypes {
var $engine=array(
5=> 'BabelFish',
9=> 'Google'
  );
 }
